import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { Readable } from 'stream';
import { spawn, execFile } from 'child_process';
import { promisify } from 'util';
import {
  buildChildSitemapXml,
  buildSitemapIndexXml,
  buildRobotsTxt,
} from './src/data/sitemapData';
import { parseTwitterUrl } from './src/utils/twitterUrl';
import { buildMediaFormats, buildPhotoFormats } from './src/utils/downloader';

const execFileAsync = promisify(execFile);

/**
 * Universal fallback resolver using yt-dlp binary for Twitter Spaces, Live Broadcasts, and videos
 */
async function resolveWithYtDlp(targetUrl: string): Promise<any | null> {
  try {
    const { stdout } = await execFileAsync('/usr/local/bin/yt-dlp', [
      '--dump-json',
      '--no-playlist',
      '--no-warnings',
      '--socket-timeout', '10',
      targetUrl,
    ], { timeout: 15000 });

    if (stdout && stdout.trim()) {
      return JSON.parse(stdout.trim());
    }
  } catch (err: any) {
    // yt-dlp was unable to extract or stream is offline
  }
  return null;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;
  const isProd = process.env.NODE_ENV === 'production';
  app.use(express.json());

  // Security Headers
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  // 1. Robots.txt
  app.get('/robots.txt', (_req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.send(buildRobotsTxt());
  });

  // 2. Sitemap Index (/sitemap.xml)
  app.get('/sitemap.xml', (_req: Request, res: Response) => {
    res.setHeader('Content-Type', 'application/xml; charset=utf-8');
    res.send(buildSitemapIndexXml());
  });

  // 3. Child Sitemap (/sitemap_1.xml)
  app.get('/sitemap_1.xml', (_req: Request, res: Response) => {
    res.setHeader('Content-Type', 'application/xml; charset=utf-8');
    res.send(buildChildSitemapXml());
  });

  // 4. API: Analyze Tweet Endpoint with multi-provider resilience
  app.post('/api/analyze', async (req: Request, res: Response) => {
    try {
      const { url } = req.body;
      if (!url) {
        res.status(400).json({ success: false, error: 'URL is required', errorCode: 'EMPTY_URL' });
        return;
      }

      const parsed = parseTwitterUrl(url);
      if (!parsed.isValid || !parsed.postId) {
        res.status(400).json({ success: false, error: parsed.error, errorCode: 'INVALID_DOMAIN' });
        return;
      }

      const postId = parsed.postId;
      const username = parsed.username || 'i';
      const isLivePost = Boolean(parsed.isLive || parsed.isSpace || parsed.isBroadcast);

      // Resilient Multi-Resolver with bot headers for VxTwitter to guarantee 200 responses:
      const resolverConfigs = [
        { url: `https://api.fxtwitter.com/2/status/${postId}`, ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
        { url: `https://api.vxtwitter.com/i/status/${postId}`, ua: 'TelegramBot (like TwitterBot)' },
        { url: `https://api.fxtwitter.com/${username}/status/${postId}`, ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
        { url: `https://api.vxtwitter.com/${username}/status/${postId}`, ua: 'Twitterbot/1.0' },
        { url: `https://api.fxtwitter.com/status/${postId}`, ua: 'Mozilla/5.0 (compatible; Discordbot/2.0; +https://discordapp.com)' },
      ];

      let data: any = null;
      let textOnlyCandidate: any = null;

      for (const config of resolverConfigs) {
        try {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 6000);
          const response = await fetch(config.url, {
            headers: {
              'User-Agent': config.ua,
              Accept: 'application/json',
            },
            signal: controller.signal,
          });
          clearTimeout(timeout);

          if (response.ok) {
            const json = await response.json();
            // Handle fxtwitter v2 (json.status), fxtwitter v1 (json.tweet), and vxtwitter
            const candidate = json.status || json.tweet || json;
            if (candidate) {
              const hasMedia = Boolean(
                (candidate.media && (candidate.media.videos?.length > 0 || candidate.media.photos?.length > 0)) ||
                (candidate.media_extended && candidate.media_extended.length > 0) ||
                (candidate.mediaURLs && candidate.mediaURLs.length > 0) ||
                candidate.embed_card ||
                candidate.quote
              );
              if (hasMedia) {
                data = candidate;
                break;
              } else if (!textOnlyCandidate && (candidate.text || candidate.id || candidate.conversationID)) {
                textOnlyCandidate = candidate;
              }
            }
          }
        } catch (_) {
          // Continue to next resolver if one fails
        }
      }

      if (!data && textOnlyCandidate) {
        data = textOnlyCandidate;
      }

      // If data wasn't found through standard resolvers or if it is a Live/Space,
      // attempt extraction via yt-dlp
      if (!data || isLivePost) {
        const ytData = await resolveWithYtDlp(parsed.normalizedUrl || url);
        if (ytData) {
          const ytFormats = ytData.formats || [];
          const mp4s = ytFormats.filter(
            (f: any) => f.ext === 'mp4' && f.vcodec !== 'none' && !f.url?.includes('.m3u8')
          );
          const m3u8 = ytFormats.find((f: any) => f.url?.includes('.m3u8'));
          const durationSec = ytData.duration || 0;
          const isLiveStream = Boolean(ytData.is_live || isLivePost || m3u8);

          const variants: any[] = [];
          for (const m of mp4s) {
            variants.push({
              url: m.url,
              content_type: 'video/mp4',
              container: 'mp4',
              bitrate: m.tbr ? m.tbr * 1000 : 1500000,
            });
          }
          if (m3u8) {
            variants.push({
              url: m3u8.url,
              content_type: 'application/x-mpegURL',
              container: 'm3u8',
            });
          }

          if (variants.length > 0) {
            const mappedFormats = buildMediaFormats(variants, durationSec, postId);
            const m = Math.floor(durationSec / 60);
            const s = Math.floor(durationSec % 60);
            const durationStr = durationSec > 0 ? `${m}:${s < 10 ? '0' : ''}${s}` : (isLiveStream ? 'Live / Replay' : '0:30');

            const previewFormat = mappedFormats.find((f) => f.format === 'MP4' && (f.quality === '720p' || f.quality === '480p')) ||
              mappedFormats.find((f) => f.format === 'MP4') ||
              mappedFormats[0];

            res.json({
              success: true,
              result: {
                tweetId: postId,
                username: ytData.uploader_id || ytData.uploader || parsed.username || 'twitter_user',
                authorName: ytData.uploader || ytData.channel || 'Twitter Creator',
                authorAvatar: undefined,
                tweetText: ytData.title || ytData.description || '',
                thumbnailUrl: ytData.thumbnail,
                duration: durationStr,
                isVideo: true,
                isGif: false,
                isLive: isLiveStream,
                isSpace: Boolean(parsed.isSpace),
                isBroadcast: Boolean(parsed.isBroadcast),
                streamUrl: m3u8?.url,
                previewUrl: previewFormat?.directUrl || m3u8?.url,
                formats: mappedFormats,
              },
            });
            return;
          }
        }
      }

      if (!data) {
        res.status(404).json({
          success: false,
          error: isLivePost
            ? 'Cette diffusion en direct ou ce Space est introuvable ou n\'est plus accessible.'
            : 'Tweet could not be found or is protected.',
          errorCode: 'PRIVATE',
        });
        return;
      }

      // 1. Check if tweet is a Quote Tweet where the outer tweet has no direct video,
      // but the quoted tweet contains the video or photos!
      let targetPost = data;
      let isQuoted = false;
      let quotedAuthor = '';

      const hasDirectVideos = Boolean(
        targetPost.media?.videos?.length ||
        targetPost.media?.all?.some((m: any) => m.type === 'video' || m.type === 'gif') ||
        targetPost.media_extended?.some((m: any) => m.type === 'video' || m.type === 'gif') ||
        (Array.isArray(targetPost.mediaURLs) && targetPost.mediaURLs.some((u: string) => u.includes('.mp4') || u.includes('video.twimg.com')))
      );

      if (!hasDirectVideos && data.quote) {
        const q = data.quote;
        const quoteHasMedia = Boolean(
          q.media?.videos?.length ||
          q.media?.all?.some((m: any) => m.type === 'video' || m.type === 'gif') ||
          q.media_extended?.some((m: any) => m.type === 'video' || m.type === 'gif') ||
          (Array.isArray(q.mediaURLs) && q.mediaURLs.some((u: string) => u.includes('.mp4') || u.includes('video.twimg.com'))) ||
          q.media?.photos?.length
        );
        if (quoteHasMedia) {
          targetPost = q;
          isQuoted = true;
          quotedAuthor = q.author?.name || q.user_name || q.author?.screen_name || 'Quoted Post';
        }
      }

      // 2. Extract video/gif media from targetPost
      const mediaList =
        (Array.isArray(targetPost.media?.videos) && targetPost.media.videos.length > 0 ? targetPost.media.videos : null) ||
        (Array.isArray(targetPost.media?.all) && targetPost.media.all.length > 0 ? targetPost.media.all : null) ||
        (Array.isArray(targetPost.media_extended) && targetPost.media_extended.length > 0 ? targetPost.media_extended : null) ||
        [];

      let videoMedia = mediaList.find(
        (m: { type: string; url: string }) => m.type === 'video' || m.type === 'gif'
      ) || (targetPost.media?.videos && targetPost.media.videos[0]) || null;

      // Also check targetPost.mediaURLs for direct .mp4 if not found in mediaList
      if (!videoMedia && Array.isArray(targetPost.mediaURLs)) {
        const mp4Url = targetPost.mediaURLs.find((u: string) => u.includes('.mp4') || u.includes('video.twimg.com'));
        if (mp4Url) {
          videoMedia = {
            type: 'video',
            url: mp4Url,
            thumbnail_url: targetPost.thumbnail_url || targetPost.mediaURLs[0],
          };
        }
      }

      // 3. If NO video/gif stream was found through resolvers, attempt extraction with yt-dlp
      if (!videoMedia || (!videoMedia.url && (!videoMedia.formats || videoMedia.formats.length === 0) && (!videoMedia.variants || videoMedia.variants.length === 0))) {
        const ytData = await resolveWithYtDlp(parsed.normalizedUrl || url);
        if (ytData && ytData.formats && ytData.formats.length > 0) {
          const ytFormats = ytData.formats || [];
          const mp4s = ytFormats.filter(
            (f: any) => f.ext === 'mp4' && f.vcodec !== 'none' && !f.url?.includes('.m3u8')
          );
          const m3u8 = ytFormats.find((f: any) => f.url?.includes('.m3u8'));
          const durationSec = ytData.duration || 0;
          const isLiveStream = Boolean(ytData.is_live || isLivePost || m3u8);

          const variants: any[] = [];
          for (const m of mp4s) {
            variants.push({
              url: m.url,
              content_type: 'video/mp4',
              container: 'mp4',
              bitrate: m.tbr ? m.tbr * 1000 : 1500000,
            });
          }
          if (m3u8) {
            variants.push({
              url: m3u8.url,
              content_type: 'application/x-mpegURL',
              container: 'm3u8',
            });
          }

          if (variants.length > 0) {
            const mappedFormats = buildMediaFormats(variants, durationSec, postId);
            const m = Math.floor(durationSec / 60);
            const s = Math.floor(durationSec % 60);
            const durationStr = durationSec > 0 ? `${m}:${s < 10 ? '0' : ''}${s}` : (isLiveStream ? 'Live / Replay' : '0:30');

            const previewFormat = mappedFormats.find((f) => f.format === 'MP4' && (f.quality === '720p' || f.quality === '480p')) ||
              mappedFormats.find((f) => f.format === 'MP4') ||
              mappedFormats[0];

            res.json({
              success: true,
              result: {
                tweetId: postId,
                username: ytData.uploader_id || ytData.uploader || targetPost.author?.screen_name || parsed.username || 'twitter_user',
                authorName: ytData.uploader || ytData.channel || targetPost.author?.name || 'Twitter Creator',
                authorAvatar: targetPost.author?.avatar_url || targetPost.user_profile_image_url,
                tweetText: ytData.title || targetPost.text || '',
                thumbnailUrl: ytData.thumbnail || targetPost.thumbnail_url,
                duration: durationStr,
                isVideo: true,
                isGif: false,
                isLive: isLiveStream,
                isSpace: Boolean(parsed.isSpace),
                isBroadcast: Boolean(parsed.isBroadcast),
                streamUrl: m3u8?.url,
                previewUrl: previewFormat?.directUrl || m3u8?.url,
                formats: mappedFormats,
              },
            });
            return;
          }
        }

        const rawPhotos =
          (Array.isArray(targetPost.media?.photos) && targetPost.media.photos.length > 0 ? targetPost.media.photos : null) ||
          (Array.isArray(data.media?.photos) && data.media.photos.length > 0 ? data.media.photos : null) ||
          (Array.isArray(targetPost.media?.all) ? targetPost.media.all.filter((m: any) => m.type === 'photo') : null) ||
          (Array.isArray(targetPost.media_extended) ? targetPost.media_extended.filter((m: any) => m.type === 'image') : null) ||
          (Array.isArray(targetPost.mediaURLs) ? targetPost.mediaURLs.filter((u: string) => !u.includes('.mp4')).map((u: string) => ({ url: u })) : null) ||
          [];

        if (rawPhotos.length > 0) {
          const photoFormats = buildPhotoFormats(rawPhotos, postId);
          res.json({
            success: true,
            result: {
              tweetId: postId,
              username: targetPost.user_screen_name || targetPost.author?.screen_name || parsed.username || 'twitter_user',
              authorName: targetPost.user_name || targetPost.author?.name || 'Twitter Creator',
              authorAvatar: targetPost.user_profile_image_url || targetPost.author?.avatar_url,
              tweetText: targetPost.text || (targetPost.raw_text?.text ? targetPost.raw_text.text : data.text || ''),
              thumbnailUrl: rawPhotos[0].url,
              duration: `${rawPhotos.length} Photo${rawPhotos.length > 1 ? 's' : ''}`,
              isVideo: false,
              isGif: false,
              isPhoto: true,
              isQuoted,
              quotedAuthor: isQuoted ? quotedAuthor : undefined,
              previewUrl: rawPhotos[0].url,
              photos: rawPhotos.map((p: any) => ({ url: p.url, width: p.width, height: p.height })),
              formats: photoFormats,
            },
          });
          return;
        }

        // Truly text-only: No video, no gif, no photos, no live stream
        res.status(422).json({
          success: false,
          error: isLivePost
            ? 'No live broadcast or audio stream was found for this link.'
            : 'This tweet contains only text without any attached videos, GIFs, or photos.',
          errorCode: 'NO_VIDEO',
        });
        return;
      }

      const isGif = videoMedia.type === 'gif' || (videoMedia.url && videoMedia.url.includes('tweet_video'));
      const durationSec = videoMedia.duration || (videoMedia.duration_millis ? videoMedia.duration_millis / 1000 : 30);

      const rawVariants = Array.isArray(videoMedia.formats) && videoMedia.formats.length > 0
        ? videoMedia.formats
        : Array.isArray(videoMedia.variants) && videoMedia.variants.length > 0
        ? videoMedia.variants
        : [];

      const variants: Array<{ bitrate?: number; content_type?: string; container?: string; url: string }> = [];
      if (rawVariants.length > 0) {
        variants.push(...rawVariants);
      } else if (videoMedia.url) {
        variants.push({
          url: videoMedia.url,
          content_type: 'video/mp4',
          bitrate: 2176000,
        });
      }

      const formats = buildMediaFormats(variants, durationSec, postId);

      const m = Math.floor(durationSec / 60);
      const s = Math.floor(durationSec % 60);
      const durationStr = durationSec > 0 ? `${m}:${s < 10 ? '0' : ''}${s}` : 'Live';

      // Pick preview video URL (preferably 720p or standard MP4 for seamless browser preview)
      const previewFormat = formats.find((f) => f.format === 'MP4' && (f.quality === '720p' || f.quality === '480p')) ||
        formats.find((f) => f.format === 'MP4') ||
        formats[0];

      res.json({
        success: true,
        result: {
          tweetId: postId,
          username: targetPost.user_screen_name || targetPost.author?.screen_name || data.author?.screen_name || parsed.username || 'twitter_user',
          authorName: targetPost.user_name || targetPost.author?.name || data.author?.name || 'Twitter Creator',
          authorAvatar: targetPost.user_profile_image_url || targetPost.author?.avatar_url || data.author?.avatar_url,
          tweetText: targetPost.text || (targetPost.raw_text?.text ? targetPost.raw_text.text : data.text || ''),
          thumbnailUrl: videoMedia.thumbnail_url || (variants[0]?.url ? undefined : undefined),
          duration: durationStr,
          isVideo: !isGif,
          isGif,
          isLive: isLivePost || Boolean(variants.some((v) => v.url?.includes('.m3u8'))),
          isSpace: Boolean(parsed.isSpace),
          isBroadcast: Boolean(parsed.isBroadcast),
          isQuoted,
          quotedAuthor: isQuoted ? quotedAuthor : undefined,
          streamUrl: variants.find((v) => v.url?.includes('.m3u8'))?.url,
          previewUrl: previewFormat?.directUrl || videoMedia.url,
          formats,
        },
      });
    } catch (err: unknown) {
      console.error('API /api/analyze error:', err);
      res.status(500).json({
        success: false,
        error: 'Internal service error while resolving tweet media.',
        errorCode: 'NETWORK',
      });
    }
  });

  // 5. API: Direct Media Proxy Download (Enforces browser download prompt & SSRF protection)
  app.all(['/api/proxy-download'], async (req: Request, res: Response) => {
    // Handle CORS preflight
    if (req.method === 'OPTIONS') {
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', '*');
      res.status(204).end();
      return;
    }

    // Only support GET and HEAD
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.status(405).json({ error: 'Method not allowed' });
      return;
    }

    try {
      const mediaUrl = req.query.url as string;
      const rawFilename = (req.query.filename as string) || '';
      const isAudioOnly = req.query.audioOnly === 'true';

      if (!mediaUrl) {
        res.status(400).json({ error: 'Missing media URL parameter.' });
        return;
      }

      // SSRF & Target Validation
      let parsedTarget: URL;
      try {
        parsedTarget = new URL(mediaUrl);
      } catch {
        res.status(400).json({ error: 'Invalid media URL format.' });
        return;
      }

      // Restrict protocol strictly to https and http
      if (parsedTarget.protocol !== 'https:' && parsedTarget.protocol !== 'http:') {
        res.status(400).json({ error: 'Unsupported protocol scheme.' });
        return;
      }

      // Disallow user credentials embedded in URL
      if (parsedTarget.username || parsedTarget.password) {
        res.status(400).json({ error: 'Credentials in URL are strictly forbidden.' });
        return;
      }

      // SSRF Whitelist Check: strictly allow official Twitter/X & Periscope CDN domains
      const hostname = parsedTarget.hostname.toLowerCase();
      const isAllowedHost =
        hostname === 'twimg.com' ||
        hostname.endsWith('.twimg.com') ||
        hostname === 'twitter.com' ||
        hostname === 'x.com' ||
        hostname.endsWith('.twitter.com') ||
        hostname.endsWith('.x.com') ||
        hostname === 'pscp.tv' ||
        hostname.endsWith('.pscp.tv');

      // Disallow IP literals (IPv4 or IPv6) and localhost to prevent SSRF
      const isIpOrLocalhost =
        /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname) ||
        hostname.includes(':') ||
        hostname === 'localhost';

      if (!isAllowedHost || isIpOrLocalhost) {
        res.status(403).json({ error: 'Access forbidden: only authorized Twitter/X media CDN hosts are permitted.' });
        return;
      }

      // Sanitize filename against path traversal and dangerous characters
      const defaultFilename = isAudioOnly ? 'getvidx_audio.mp3' : 'getvidx_video.mp4';
      const sanitizedBase = path.basename(rawFilename).replace(/[^\w\d_.-]/g, '_').trim();
      const safeFilename = sanitizedBase && sanitizedBase !== '.' ? sanitizedBase : defaultFilename;

      const abortController = new AbortController();
      const timeoutId = setTimeout(() => abortController.abort(), 60000); // 60s timeout
      req.on('close', () => abortController.abort());

      // Stream request to upstream Twitter CDN
      const upstream = await fetch(mediaUrl, {
        method: req.method === 'HEAD' ? 'HEAD' : 'GET',
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          Referer: 'https://twitter.com/',
          Accept: '*/*',
        },
        signal: abortController.signal,
      });

      clearTimeout(timeoutId);

      if (!upstream.ok) {
        const errorMsg =
          upstream.status === 404 || upstream.status === 410
            ? 'The video media link has expired or was removed by Twitter.'
            : `Provider returned HTTP ${upstream.status} while fetching media.`;
        res.status(upstream.status >= 400 && upstream.status < 600 ? upstream.status : 502).json({
          error: errorMsg,
          upstreamStatus: upstream.status,
        });
        return;
      }

      if (req.method === 'HEAD') {
        const headType = safeFilename.endsWith('.mp3')
          ? 'audio/mpeg'
          : safeFilename.endsWith('.m4a')
          ? 'audio/mp4'
          : safeFilename.endsWith('.gif')
          ? 'image/gif'
          : safeFilename.endsWith('.jpg') || safeFilename.endsWith('.jpeg')
          ? 'image/jpeg'
          : safeFilename.endsWith('.png')
          ? 'image/png'
          : safeFilename.endsWith('.webp')
          ? 'image/webp'
          : safeFilename.endsWith('.m3u8')
          ? 'application/vnd.apple.mpegurl'
          : 'video/mp4';
        res.setHeader('Content-Type', headType);
        res.setHeader(
          'Content-Disposition',
          `attachment; filename="${safeFilename}"; filename*=UTF-8''${encodeURIComponent(safeFilename)}`
        );
        res.end();
        return;
      }

      // Read entire media buffer into memory before sending to client.
      // This guarantees the moov atom and video container are 100% complete,
      // avoiding truncated or corrupted video files that fail to play.
      const arrayBuffer = await upstream.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);

      if (buffer.length === 0) {
        res.status(502).json({ error: 'Received empty stream from media provider.' });
        return;
      }

      let contentType = 'video/mp4';
      if (safeFilename.endsWith('.mp3')) contentType = 'audio/mpeg';
      else if (safeFilename.endsWith('.m4a')) contentType = 'audio/mp4';
      else if (safeFilename.endsWith('.gif')) contentType = 'image/gif';
      else if (safeFilename.endsWith('.jpg') || safeFilename.endsWith('.jpeg')) contentType = 'image/jpeg';
      else if (safeFilename.endsWith('.png')) contentType = 'image/png';
      else if (safeFilename.endsWith('.webp')) contentType = 'image/webp';
      else if (safeFilename.endsWith('.m3u8')) contentType = 'application/vnd.apple.mpegurl';
      else if (safeFilename.endsWith('.mp4')) contentType = 'video/mp4';

      // Safe Content-Disposition header forcing direct download across all desktop & mobile browsers
      const disposition = `attachment; filename="${safeFilename}"; filename*=UTF-8''${encodeURIComponent(safeFilename)}`;

      // Handle HTTP Range requests (crucial for iOS Safari, mobile players, and download managers)
      const rangeHeader = req.headers.range;
      if (rangeHeader) {
        const parts = rangeHeader.replace(/bytes=/, '').split('-');
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : buffer.length - 1;

        if (!isNaN(start) && start < buffer.length) {
          const actualEnd = Math.min(end, buffer.length - 1);
          const chunk = buffer.subarray(start, actualEnd + 1);

          res.status(206);
          res.setHeader('Content-Range', `bytes ${start}-${actualEnd}/${buffer.length}`);
          res.setHeader('Content-Length', chunk.length.toString());
          res.setHeader('Content-Type', contentType);
          res.setHeader('Content-Disposition', disposition);
          res.setHeader('Accept-Ranges', 'bytes');
          res.setHeader('Access-Control-Allow-Origin', '*');
          res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition, Content-Length, Content-Range');
          res.setHeader('Cache-Control', 'public, max-age=86400');
          res.end(chunk);
          return;
        }
      }

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', disposition);
      res.setHeader('Content-Length', buffer.length.toString());
      res.setHeader('Accept-Ranges', 'bytes');
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition, Content-Length, Content-Range');
      res.setHeader('Cache-Control', 'public, max-age=86400');

      res.end(buffer);
    } catch (err: any) {
      if (err.name === 'AbortError') {
        return;
      }
      console.error('Proxy download handler error:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Internal server error while processing media download.' });
      }
    }
  });

  // 5b. API: Live Stream & Space Converter / Downloader using FFmpeg (Streams MP4, MP3, or M3U8)
  app.all(['/api/live-download'], async (req: Request, res: Response) => {
    // Handle CORS preflight
    if (req.method === 'OPTIONS') {
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', '*');
      res.status(204).end();
      return;
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.status(405).json({ error: 'Method not allowed' });
      return;
    }

    try {
      const mediaUrl = req.query.url as string;
      const rawFilename = (req.query.filename as string) || '';
      const requestedFormat = ((req.query.format as string) || 'mp4').toLowerCase();

      if (!mediaUrl) {
        res.status(400).json({ error: 'Missing live stream URL parameter.' });
        return;
      }

      let parsedTarget: URL;
      try {
        parsedTarget = new URL(mediaUrl);
      } catch {
        res.status(400).json({ error: 'Invalid live stream URL format.' });
        return;
      }

      if (parsedTarget.protocol !== 'https:' && parsedTarget.protocol !== 'http:') {
        res.status(400).json({ error: 'Unsupported protocol scheme.' });
        return;
      }

      const hostname = parsedTarget.hostname.toLowerCase();
      const isAllowedHost =
        hostname === 'twimg.com' ||
        hostname.endsWith('.twimg.com') ||
        hostname === 'twitter.com' ||
        hostname === 'x.com' ||
        hostname.endsWith('.twitter.com') ||
        hostname.endsWith('.x.com') ||
        hostname === 'pscp.tv' ||
        hostname.endsWith('.pscp.tv');

      const isIpOrLocalhost =
        /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname) ||
        hostname.includes(':') ||
        hostname === 'localhost';

      if (!isAllowedHost || isIpOrLocalhost) {
        res.status(403).json({ error: 'Access forbidden: only authorized Twitter/X media CDN hosts are permitted.' });
        return;
      }

      // If format is m3u8 playlist, fetch text and stream back with proper CORS & attachment headers
      if (requestedFormat === 'm3u8') {
        const upstream = await fetch(mediaUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            Referer: 'https://twitter.com/',
            Accept: '*/*',
          },
        });

        if (!upstream.ok) {
          res.status(upstream.status).json({
            error: 'The live stream playlist has expired or is offline.',
          });
          return;
        }

        const text = await upstream.text();
        const safeName = path.basename(rawFilename).replace(/[^\w\d_.-]/g, '_') || 'stream.m3u8';
        res.setHeader('Content-Type', 'application/vnd.apple.mpegurl; charset=utf-8');
        res.setHeader('Content-Disposition', `attachment; filename="${safeName}"; filename*=UTF-8''${encodeURIComponent(safeName)}`);
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.send(text);
        return;
      }

      // If format is mp3 or mp4, remux in real time with FFmpeg
      const isMp3 = requestedFormat === 'mp3' || requestedFormat === 'm4a';
      const defaultFilename = isMp3 ? 'getvidx_live_audio.mp3' : 'getvidx_live_video.mp4';
      const sanitizedBase = path.basename(rawFilename).replace(/[^\w\d_.-]/g, '_').trim();
      const safeFilename = sanitizedBase && sanitizedBase !== '.' ? sanitizedBase : defaultFilename;

      const contentType = isMp3 ? 'audio/mpeg' : 'video/mp4';
      const disposition = `attachment; filename="${safeFilename}"; filename*=UTF-8''${encodeURIComponent(safeFilename)}`;

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', disposition);
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');

      if (req.method === 'HEAD') {
        res.end();
        return;
      }

      const ffmpegArgs = isMp3
        ? [
            '-loglevel', 'error',
            '-reconnect', '1',
            '-reconnect_at_eof', '1',
            '-reconnect_streamed', '1',
            '-reconnect_delay_max', '5',
            '-timeout', '10000000',
            '-headers', 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\nReferer: https://twitter.com/\r\n',
            '-i', mediaUrl,
            '-t', '7200',
            '-vn',
            '-c:a', 'libmp3lame',
            '-b:a', '128k',
            '-f', 'mp3',
            'pipe:1',
          ]
        : [
            '-loglevel', 'error',
            '-reconnect', '1',
            '-reconnect_at_eof', '1',
            '-reconnect_streamed', '1',
            '-reconnect_delay_max', '5',
            '-timeout', '10000000',
            '-headers', 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\nReferer: https://twitter.com/\r\n',
            '-i', mediaUrl,
            '-t', '7200',
            '-c', 'copy',
            '-movflags', 'frag_keyframe+empty_moov+default_base_moof',
            '-f', 'mp4',
            'pipe:1',
          ];

      const ffmpeg = spawn('ffmpeg', ffmpegArgs);

      ffmpeg.stdout.pipe(res);

      let ffmpegErrorOutput = '';
      ffmpeg.stderr.on('data', (data) => {
        ffmpegErrorOutput += data.toString();
      });

      ffmpeg.on('error', (procErr) => {
        console.error('FFmpeg process error:', procErr);
        if (!res.headersSent) {
          res.status(500).json({ error: 'Failed to start live media converter.' });
        }
      });

      ffmpeg.on('close', (code) => {
        if (code !== 0 && !res.writableEnded) {
          console.warn(`FFmpeg closed with code ${code}: ${ffmpegErrorOutput}`);
          if (!res.headersSent) {
            res.status(502).json({
              error: 'The live stream could not be converted or has ended.',
              details: ffmpegErrorOutput,
            });
          }
        }
      });

      req.on('close', () => {
        try {
          ffmpeg.kill('SIGKILL');
        } catch (_) {}
      });
    } catch (err: any) {
      console.error('Live download error:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Internal server error while initiating live stream download.' });
      }
    }
  });

  // 6. Mount Vite middleware for development or serve dist for production
  if (!isProd) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[GetVidX] Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
