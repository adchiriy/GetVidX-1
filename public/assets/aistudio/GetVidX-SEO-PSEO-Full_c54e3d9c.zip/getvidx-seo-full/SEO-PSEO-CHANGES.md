# GetVidX SEO / pSEO repair notes

This package preserves the existing app and applies targeted SEO fixes.

## Changes made
- Localized canonical and Open Graph URLs now include the active locale prefix (English remains unprefixed).
- Hreflang alternates remain paired across `en`, `es`, `fr`, `pt`, `ar`, plus `x-default`.
- Removed the hard-coded `2026-03-20` sitemap `lastmod` values instead of publishing dates that do not represent actual page edits.
- Related pSEO guides and the breadcrumb home link now use crawlable anchor elements with real `href` targets while preserving client-side navigation.
- Revised several SEO descriptions and claims that implied guaranteed 1080p, zero quality loss, or universal source capabilities.
- Generic HTML metadata no longer promises 1080p/MP3/GIF availability for every source.

## Important remaining limitation
The project still updates per-route metadata in the browser with React. This means the initial HTML response for every route is not independently pre-rendered with its own title, description, canonical and structured data. For the strongest SEO and social-sharing previews, implement server-side rendering or static pre-rendering for the homepage and each published pSEO/legal route. Do not claim this is fixed by the current patch.

## Checks
- Source-level review of canonical URL construction, hreflang generation, sitemap XML generation and pSEO links performed.
- Automated production build/type-check could not be completed in this environment because dependency installation did not finish. Run `npm install` (or the project's supported package manager), then `npm run lint` and `npm run build` before deployment.

## Before publishing
- Verify every URL listed in the sitemap returns HTTP 200 and a meaningful page.
- Verify each localized page has a self-canonical and reciprocal hreflang links.
- Confirm that every format/quality mentioned in copy is actually supported by the live downloader.
- Add only pages with unique, useful content; avoid publishing thin near-duplicate pSEO pages.
